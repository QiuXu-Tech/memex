"""Narrow, interactive approval client for the P1 development host.

No unattended accept path, remembered grants, credential entry, permission
expansion or device-verification proof is implemented. Protocol tests use
in-memory fixtures; a live run requires an actual interactive terminal.
"""
import hashlib
import json
import select
import sys
import time


def terminal_line(stream, timeout):
    if timeout <= 0 or not select.select([stream], [], [], timeout)[0]:
        return ''
    return stream.readline(1025)


class InteractiveApprovals:
    def __init__(self, input_stream=None, output_stream=None, *, record=None, read_line=None):
        self.input = input_stream or sys.stdin
        self.output = output_stream or sys.stderr
        if not self.input.isatty() or not self.output.isatty():
            raise ValueError('interactive approval requires a human-operated terminal')
        self.record = record or (lambda event, **fields: None)
        self.read_line = read_line or terminal_line
        self.seen = set()

    def handle(self, message, *, thread_id, turn_id, timeout):
        params = message.get('params', {})
        identifier, method = message.get('id'), message.get('method')
        if (not isinstance(identifier, (str, int)) or isinstance(identifier, bool)
                or not isinstance(params, dict) or not thread_id or not turn_id
                or params.get('threadId') != thread_id or params.get('turnId') != turn_id):
            raise ValueError('approval request scope does not match the active turn')
        key = (type(identifier).__name__, identifier)
        if key in self.seen:
            raise ValueError('replayed approval request identifier')
        if len(self.seen) >= 8:
            raise ValueError('interactive approval request budget exhausted')
        encoded = json.dumps(message, sort_keys=True, ensure_ascii=True)
        if len(encoded.encode()) > 16384:
            raise ValueError('unsupported oversized approval request')
        form = method == 'mcpServer/elicitation/request'
        if form:
            schema = params.get('requestedSchema')
            if (params.get('serverName') != 'memex' or params.get('mode') != 'form'
                    or not isinstance(schema, dict) or schema.get('type') != 'object'
                    or schema.get('properties') != {} or schema.get('required', []) not in ([], None)
                    or set(schema) - {'type', 'properties', 'required', '$schema'}):
                raise ValueError('unsupported MCP form; use a client for this actual request type')
        elif method in ('item/tool/requestUserInput', 'tool/requestUserInput'):
            questions = params.get('questions')
            if not isinstance(questions, list) or not 1 <= len(questions) <= 3:
                raise ValueError('unsupported approval questions')
            ids = set()
            for question in questions:
                if (not isinstance(question, dict) or not isinstance(question.get('id'), str)
                        or not question['id'] or question['id'] in ids or question.get('isSecret')
                        or question.get('isOther') or not isinstance(question.get('options'), list)
                        or not 1 <= len(question['options']) <= 8):
                    raise ValueError('unsupported secret, free-form or ambiguous approval question')
                ids.add(question['id'])
                labels = [x.get('label') for x in question['options'] if isinstance(x, dict)]
                if (len(labels) != len(question['options']) or not all(isinstance(x, str) and x for x in labels)
                        or len(set(labels)) != len(labels)):
                    raise ValueError('unsupported duplicate or invalid approval options')
        else:
            raise ValueError('unsupported approval method; no permission expansion is provided')
        self.seen.add(key)
        self.record('approval/request', requestId=identifier, method=method,
                    threadId=thread_id, turnId=turn_id,
                    requestSha256=hashlib.sha256(encoded.encode()).hexdigest())
        # JSON escaping prevents source-controlled terminal escape sequences.
        self.output.write('\nP1 host approval request (only this request):\n' + encoded + '\n')
        self.output.flush()
        deadline = time.monotonic() + max(0, min(timeout, 120))
        if form:
            self.output.write('Type accept, decline, or cancel. Empty/timeout cancels: ')
            self.output.flush()
            action = self.read_line(self.input, deadline - time.monotonic()).strip()
            if action not in ('accept', 'decline', 'cancel'):
                action = 'cancel'
            response = {'action': action, 'content': {} if action == 'accept' else None}
        else:
            answers = {}
            for question in questions:
                self.output.write(json.dumps(question['id']) + ': ' + ', '.join(
                    f'{i + 1}={json.dumps(option["label"])}' for i, option in enumerate(question['options']))
                    + '. Enter a number; empty/timeout cancels: ')
                self.output.flush()
                value = self.read_line(self.input, deadline - time.monotonic()).strip()
                if not value.isascii() or not value.isdigit() or not 1 <= int(value) <= len(question['options']):
                    answers = {}
                    break
                answers[question['id']] = {'answers': [question['options'][int(value) - 1]['label']]}
            response = {'answers': answers}
        self.record('approval/response', requestId=identifier, method=method,
                    threadId=thread_id, turnId=turn_id, response=response,
                    source='interactive_terminal', identityAttested=False)
        return response
