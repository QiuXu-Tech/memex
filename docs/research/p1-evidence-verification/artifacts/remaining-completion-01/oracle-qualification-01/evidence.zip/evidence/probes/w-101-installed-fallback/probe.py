import json, pathlib, socket, sys
cfg = json.loads(pathlib.Path(sys.argv[1]).read_text())
checks = {}
checks["allowed_read"] = (pathlib.Path(cfg["workspace"]) / "allowed.txt").read_text() == "probe-allowed"
target = pathlib.Path(cfg["output"]) / "allowed-write.txt"
target.write_text(cfg["nonce"])
checks["allowed_write"] = target.read_text() == cfg["nonce"]
try:
    pathlib.Path(cfg["private_file"]).read_bytes()
    checks["private_read_denied"] = False
except (PermissionError, FileNotFoundError):
    checks["private_read_denied"] = True
try:
    pathlib.Path(cfg["private_file"]).write_text("forbidden-probe-write")
    checks["private_write_denied"] = False
except (PermissionError, FileNotFoundError):
    checks["private_write_denied"] = True
try:
    with socket.create_connection(("127.0.0.1", cfg["port"]), timeout=0.5):
        checks["loopback_connection_denied"] = False
except OSError:
    checks["loopback_connection_denied"] = True
print(json.dumps({"nonce": cfg["nonce"], "checks": checks}))
raise SystemExit(0 if all(checks.values()) else 3)
